#!/bin/bash
exec java -jar oltp-service-dubbo-1.0-SNAPSHOT.jar >> /opt/dubbo.out 2>&1 
